# routing-data-source
Example of using Spring RoutingDataSource and custom annotations to determine concrete DataSource
