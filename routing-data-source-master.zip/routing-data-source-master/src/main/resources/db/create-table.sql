CREATE TABLE some_table (
  id   INTEGER PRIMARY KEY,
  name VARCHAR(30),
  val VARCHAR(30)
);