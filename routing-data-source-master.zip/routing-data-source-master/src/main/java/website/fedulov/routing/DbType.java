package website.fedulov.routing;

public enum DbType {
   MASTER,
   REPLICA1,
}